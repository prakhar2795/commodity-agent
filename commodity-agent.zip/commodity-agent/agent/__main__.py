"""CLI.

python -m agent run [--digest] [--no-send]     full cycle (what the schedule runs)
python -m agent backtest [gold_mini ...]       test the rules on 10 years of history
python -m agent open gold_mini long 118450 --stop 116900 --target 121550 --lots 1
python -m agent close gold_mini                remove a real position you exited
python -m agent status                         show open positions + paper scorecard
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import logging
import os
import sys

from . import backtest, report, runner, state


def main(argv=None):
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    p = argparse.ArgumentParser(prog="agent")
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run")
    r.add_argument("--digest", action="store_true", help="send the full daily brief even without changes")
    r.add_argument("--no-send", action="store_true")
    b = sub.add_parser("backtest")
    b.add_argument("keys", nargs="*")
    b.add_argument("--period", default="10y")
    o = sub.add_parser("open")
    o.add_argument("key")
    o.add_argument("side", choices=["long", "short"])
    o.add_argument("entry", type=float)
    o.add_argument("--stop", type=float, required=True)
    o.add_argument("--target", type=float, required=True)
    o.add_argument("--lots", type=int, default=1)
    c = sub.add_parser("close")
    c.add_argument("key")
    sub.add_parser("status")
    a = p.parse_args(argv)
    cfg = runner.load_config()

    if a.cmd == "run":
        if a.digest:
            os.environ["AGENT_DIGEST"] = "1"
        s = runner.run(cfg, send=not a.no_send)
        print(report.telegram_text(s, []))
    elif a.cmd == "backtest":
        keys = a.keys or [k for k, v in cfg["instruments"].items() if v.get("enabled", True)]
        for k in keys:
            res = backtest.backtest_instrument(k, cfg, period=a.period)
            print(f"\n== {cfg['instruments'][k]['name']} ==")
            print(json.dumps(res["stats"], indent=1))
    elif a.cmd == "open":
        pos = state.load_positions()
        pos["real"] = [x for x in pos["real"] if x["key"] != a.key]
        pos["real"].append({"key": a.key, "side": a.side, "entry": a.entry, "stop": a.stop, "stop0": a.stop,
                            "target": a.target, "lots": a.lots, "opened": dt.date.today().isoformat(),
                            "extreme": a.entry, "t1_done": False})
        state.save_positions(pos)
        print("recorded", pos["real"][-1])
    elif a.cmd == "close":
        pos = state.load_positions()
        pos["real"] = [x for x in pos["real"] if x["key"] != a.key]
        state.save_positions(pos)
        print("removed", a.key)
    elif a.cmd == "status":
        print(json.dumps(state.load_positions(), indent=1))
        print(json.dumps(report.journal_stats(state.read_journal()), indent=1))


if __name__ == "__main__":
    sys.exit(main())
