"""Event-risk calendar: flags high-impact releases so the agent avoids fresh entries into them."""
from __future__ import annotations

import datetime as dt

LABELS = {
    "fomc": "FOMC rate decision (~11:30 PM IST)",
    "cpi": "US CPI (~6:00 PM IST)",
    "nfp": "US Non-Farm Payrolls (~6:00 PM IST)",
    "eia_crude": "EIA crude inventories (~8:00 PM IST)",
    "eia_gas": "EIA natural gas storage (~8:00 PM IST)",
}


def _first_friday(d: dt.date) -> dt.date:
    first = d.replace(day=1)
    return first + dt.timedelta(days=(4 - first.weekday()) % 7)


def events_on(day: dt.date, kinds: list[str], calendar: dict) -> list[str]:
    out = []
    if "fomc" in kinds and day.isoformat() in calendar.get("fomc", []):
        out.append(LABELS["fomc"])
    if "cpi" in kinds and day.isoformat() in calendar.get("cpi", []):
        out.append(LABELS["cpi"])
    if "nfp" in kinds and day == _first_friday(day):
        out.append(LABELS["nfp"])
    if "eia_crude" in kinds and day.weekday() == 2:
        out.append(LABELS["eia_crude"])
    if "eia_gas" in kinds and day.weekday() == 3:
        out.append(LABELS["eia_gas"])
    return out


def upcoming(kinds: list[str], calendar: dict, today: dt.date | None = None, days: int = 3) -> list[dict]:
    today = today or dt.date.today()
    res = []
    for i in range(days + 1):
        d = today + dt.timedelta(days=i)
        for e in events_on(d, kinds, calendar):
            res.append({"date": d.isoformat(), "event": e, "in_days": i})
    return res


def expiry_warning(key: str, calendar: dict, today: dt.date | None = None, warn_days: int = 5) -> str | None:
    exp = calendar.get("expiries", {}).get(key)
    if not exp:
        return None
    today = today or dt.date.today()
    left = (dt.date.fromisoformat(exp) - today).days
    if 0 <= left <= warn_days:
        return f"Contract expires {exp} ({left} days): roll to next month or exit."
    return None
