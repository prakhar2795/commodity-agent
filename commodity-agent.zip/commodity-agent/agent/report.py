"""Reports: JSON (for the Claude brief), Markdown (repo), HTML (email), short text (Telegram)."""
from __future__ import annotations

import datetime as dt
import html
import json

import pandas as pd

from . import state

ICON = {"BUY": "🟢", "SELL": "🔴", "EXIT": "⛔", "BOOK PARTIAL": "💰", "HOLD": "🔵", "WATCH": "🟡", "NO TRADE": "⚪"}


def _icon(a: str) -> str:
    return ICON.get(a.split(" (")[0], "⚪")


def macro_snapshot(macro: dict) -> dict:
    out = {}
    for k, s in macro.items():
        if s is None or len(s) < 21:
            continue
        out[k] = {"last": round(float(s.iloc[-1]), 3),
                  "chg_5d_pct": round(float(s.iloc[-1] / s.iloc[-6] - 1) * 100, 2),
                  "chg_20d_pct": round(float(s.iloc[-1] / s.iloc[-21] - 1) * 100, 2)}
    return out


def journal_stats(rows: list[dict]) -> dict:
    if not rows:
        return {"trades": 0}
    r = pd.Series([float(x["r_multiple"]) for x in rows])
    wins, losses = r[r > 0], r[r <= 0]
    eq = r.cumsum()
    return {"trades": int(len(r)), "win_rate_pct": round(len(wins) / len(r) * 100, 1),
            "avg_win_r": round(float(wins.mean()), 2) if len(wins) else 0,
            "avg_loss_r": round(float(losses.mean()), 2) if len(losses) else 0,
            "expectancy_r": round(float(r.mean()), 2),
            "profit_factor": round(float(wins.sum() / abs(losses.sum())), 2) if losses.sum() else None,
            "max_drawdown_r": round(float((eq - eq.cummax()).min()), 2), "total_r": round(float(r.sum()), 2)}


def _clean(obj):
    if isinstance(obj, dict):
        return {k: _clean(v) for k, v in obj.items() if not str(k).startswith("_")}
    if isinstance(obj, list):
        return [_clean(v) for v in obj]
    return obj


def _plan_line(r: dict) -> str:
    real = r.get("manage", {}).get("real")
    if real:
        p = real["position"]
        s = f"{p['side'].upper()} {p['lots']} lot @ {p['entry']} | stop {p['stop']} | T1 {p['target']}"
        if real["action"] == "EXIT":
            s += f" | EXIT ~{real.get('fill')} ({real['reason']})"
        notes = "; ".join(real.get("notes", []))
        return s + (f" | {notes}" if notes else "")
    d = r["decision"]
    if "plan" in d:
        p = d["plan"]
        lots = p.get("lots")
        s = f"entry ~{p['entry']} | stop {p['stop']} | T1 {p['target']}"
        if lots is not None:
            s += f" | {lots} x {p.get('contract', '')}, risk INR {p.get('risk_inr', 0):,.0f}"
        if d.get("blocked"):
            s += f" | blocked: {d['blocked']}"
        if d.get("notes"):
            s += " | wait: " + "; ".join(d["notes"])
        return s
    return "; ".join(d.get("notes", []))


def markdown(summary: dict) -> str:
    L = [f"# Commodity agent report — {summary['generated']}", "",
         "_Decision support only, not financial advice. MCX prices are implied from global futures x USDINR unless calibrated._", ""]
    m = summary["macro"]
    if m:
        L += ["## Macro", "", "| Series | Last | 5d % | 20d % |", "|---|---|---|---|"]
        L += [f"| {k} | {v['last']} | {v['chg_5d_pct']} | {v['chg_20d_pct']} |" for k, v in m.items()]
        L.append("")
    L += ["## Signals", "", "| | Instrument | Action | Score (prev, 5d ago) | Regime | MCX-implied | Plan |", "|---|---|---|---|---|---|---|"]
    for r in sorted(summary["results"], key=lambda x: -abs(x["score"])):
        L.append(f"| {_icon(r['action'])} | {r['name']} | **{r['action']}** | {r['score']:+.0f} ({r['score_prev']:+.0f}, {r['score_5d']:+.0f}) "
                 f"| {r['regime']} | {r['close']:,} {r['unit']} | {_plan_line(r)} |")
    L.append("")
    for r in summary["results"]:
        i = r["ind"]
        L += [f"### {r['name']} ({r['symbol']}) — {r['action']}, {r['conviction']} conviction", "",
              f"- Why bullish: {', '.join(r['explain']['bullish']) or '—'}",
              f"- Why bearish: {', '.join(r['explain']['bearish']) or '—'}",
              f"- RSI {i.get('rsi')} · ADX {i.get('adx')} (+DI {i.get('pdi')} / -DI {i.get('mdi')}) · MACD hist {i.get('macd_hist')} · "
              f"ATR {i.get('atr')} ({i.get('atr_pct')}%) · %B {i.get('bb_pctb')} · squeeze {'ON' if r['squeeze'] else 'off'}",
              f"- EMA20 {i.get('ema20')} · EMA50 {i.get('ema50')} · EMA200 {i.get('ema200')} · Supertrend {i.get('st')} · 20d channel {i.get('dc_lo')}–{i.get('dc_hi')}",
              f"- Support {r['levels']['support']} · Resistance {r['levels']['resistance']} · Pivots {r['levels']['pivots']}"]
        if r["events"]:
            L.append("- Events: " + "; ".join(f"{e['date']} {e['event']}" for e in r["events"]))
        if r.get("expiry"):
            L.append(f"- ⚠️ {r['expiry']}")
        L.append("")
    ps = summary["paper_stats"]
    L += ["## Paper-trading scorecard", "", "```", json.dumps(ps, indent=1), "```", ""]
    L += ["## Open positions", "", "```", json.dumps(summary["positions"], indent=1), "```"]
    if summary["errors"]:
        L += ["", "## Errors", ""] + [f"- {e}" for e in summary["errors"]]
    return "\n".join(L)


def telegram_text(summary: dict, changes: list[dict]) -> str:
    rows = changes or summary["results"]
    head = "⚡ Signal change" if changes else "📊 Daily commodity brief"
    L = [f"{head} — {summary['generated'][:16].replace('T', ' ')}"]
    for r in sorted(rows, key=lambda x: -abs(x["score"])):
        L.append(f"\n{_icon(r['action'])} {r['name']}: {r['action']}  (score {r['score']:+.0f}, {r['regime']})")
        L.append(f"   {r['close']:,} {r['unit']} · {_plan_line(r)}")
        top = (r["explain"]["bullish"] if r["score"] >= 0 else r["explain"]["bearish"])[:2]
        if top:
            L.append("   " + " · ".join(top))
    L.append("\nNot financial advice. Confirm price on MCX before acting.")
    return "\n".join(L)[:4000]


def email_html(summary: dict, changes: list[dict]) -> str:
    rows = []
    for r in sorted(summary["results"], key=lambda x: -abs(x["score"])):
        hi = " style='background:#fff7d6'" if r in changes else ""
        rows.append(f"<tr{hi}><td>{_icon(r['action'])} {html.escape(r['name'])}</td><td><b>{r['action']}</b></td>"
                    f"<td>{r['score']:+.0f}</td><td>{r['regime']}</td><td>{r['close']:,} {r['unit']}</td>"
                    f"<td>{html.escape(_plan_line(r))}</td></tr>")
    md = html.escape(markdown(summary))
    return (f"<div style='font-family:Arial,sans-serif'><h2>Commodity agent — {summary['generated']}</h2>"
            "<table border='1' cellpadding='6' style='border-collapse:collapse;font-size:13px'>"
            "<tr><th>Instrument</th><th>Action</th><th>Score</th><th>Regime</th><th>MCX-implied</th><th>Plan</th></tr>"
            + "".join(rows) + "</table><p style='color:#777'>Highlighted rows changed since last run. "
            "Decision support only, not financial advice.</p><details><summary>Full report</summary>"
            f"<pre style='font-size:12px'>{md}</pre></details></div>")


def write_all(summary: dict):
    out = state.ROOT / "reports"
    (out / "history").mkdir(parents=True, exist_ok=True)
    clean = _clean(summary)
    (out / "latest.json").write_text(json.dumps(clean, indent=2, default=str))
    md = markdown(summary)
    (out / "latest.md").write_text(md)
    (out / "history" / f"{dt.date.today().isoformat()}.md").write_text(md)
