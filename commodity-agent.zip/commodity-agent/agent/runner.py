"""One full agent cycle: data -> analysis -> position management -> reports -> alerts."""
from __future__ import annotations

import datetime as dt
import json
import logging
from pathlib import Path

import pandas as pd
import yaml

from . import alerts, data, engine, report, signals as sig, state

log = logging.getLogger(__name__)


def load_config(path: str | Path | None = None) -> dict:
    path = Path(path or state.ROOT / "config.yaml")
    return yaml.safe_load(path.read_text())


def fetch_macro(cfg: dict, loader=None) -> dict:
    out = {}
    for name, sym in cfg.get("macro", {}).items():
        try:
            out[name] = data.fetch(sym, loader=loader)["close"]
        except Exception as e:  # noqa: BLE001
            log.warning("macro %s (%s) failed: %s", name, sym, e)
    return out


def _risk_inr(pos: dict, lot_mult: float) -> float:
    lot_mult = pos.get("lot_multiplier", lot_mult)
    return abs(pos["entry"] - pos["stop"]) * lot_mult * pos.get("lots", 1)


def _close_paper(pos: dict, fill: float, reason: str, inst: dict, today: str):
    sign = 1 if pos["side"] == "long" else -1
    r0 = abs(pos["entry"] - pos["stop0"]) or 1e-9
    # half booked at T1 if reached
    if pos.get("t1_done"):
        r = 0.5 * sign * (pos["target"] - pos["entry"]) / r0 + 0.5 * sign * (fill - pos["entry"]) / r0
        pnl = 0.5 * sign * (pos["target"] - pos["entry"]) + 0.5 * sign * (fill - pos["entry"])
    else:
        r = sign * (fill - pos["entry"]) / r0
        pnl = sign * (fill - pos["entry"])
    state.journal({"opened": pos["opened"], "closed": today, "key": pos["key"], "side": pos["side"],
                   "entry": pos["entry"], "exit": fill, "stop0": pos["stop0"], "lots": pos["lots"],
                   "r_multiple": round(r, 2), "pnl_inr": round(pnl * pos.get("lot_multiplier", inst["lot_multiplier"]) * pos["lots"], 0),
                   "reason": reason})


def run(cfg: dict | None = None, loader=None, send: bool = True, now: dt.datetime | None = None) -> dict:
    cfg = cfg or load_config()
    acc = cfg["account"]
    cap = engine.capital(cfg)
    today = dt.date.today().isoformat()
    macro = fetch_macro(cfg, loader)
    positions = state.load_positions()
    last_sig = state.load_signals()
    results, errors = [], []

    for key, inst in cfg["instruments"].items():
        if inst.get("enabled", True) is False:
            continue
        try:
            results.append(engine.analyse(key, inst, cfg, loader, macro, now))
        except Exception as e:  # noqa: BLE001
            log.exception("analysis failed for %s", key)
            errors.append(f"{inst['name']}: {e}")

    by_key = {r["key"]: r for r in results}
    for book in ("real", "paper"):
        keep = []
        for pos in positions.get(book, []):
            r = by_key.get(pos["key"])
            if r is None:
                keep.append(pos)
                continue
            inst = cfg["instruments"][pos["key"]]
            if pos.get("last_bar") != r["bar_date"]:
                act = engine.manage_position(pos, r["_row"], r["score"], cfg)
                pos["last_bar"] = r["bar_date"]
            else:
                act = {"action": "HOLD", "reason": "no new daily bar", "notes": []}
            # live intraday stop check on the still-forming bar
            lv = r["_live_row"]
            sign = 1 if pos["side"] == "long" else -1
            if act["action"] != "EXIT" and ((sign > 0 and lv["low"] <= pos["stop"]) or (sign < 0 and lv["high"] >= pos["stop"])):
                act = {"action": "EXIT", "reason": "stop-loss hit intraday", "fill": pos["stop"]}
            act["position"] = dict(pos)
            act["open_risk_inr"] = round(_risk_inr(pos, inst["lot_multiplier"]), 0)
            r.setdefault("manage", {})[book] = act
            if act["action"] == "EXIT":
                if book == "paper":
                    _close_paper(pos, act["fill"], act["reason"], inst, today)
                continue
            keep.append(pos)
        positions[book] = keep

    # ---- portfolio-level limits for new entries
    for book in ("real", "paper"):
        if book == "paper" and not acc.get("paper_trading"):
            continue
        held = {p["key"] for p in positions[book]}
        open_risk = sum(_risk_inr(p, cfg["instruments"][p["key"]]["lot_multiplier"]) for p in positions[book])
        for r in sorted(results, key=lambda x: -abs(x["score"])):
            dcs = r["decision"]
            if dcs["action"] not in ("BUY", "SELL") or r["key"] in held:
                continue
            inst = cfg["instruments"][r["key"]]
            plan = dcs["plan"]
            lots, per_lot = sig.lots_for(cap, acc["risk_per_trade_pct"], plan["entry"], plan["stop"], inst["lot_multiplier"])
            plan["contract"] = inst["name"]
            for alt in ([] if lots >= 1 else inst.get("smaller", [])):
                l2, p2 = sig.lots_for(cap, acc["risk_per_trade_pct"], plan["entry"], plan["stop"], alt["lot_multiplier"])
                if l2 >= 1:  # fall back to a smaller contract that fits the risk budget
                    lots, per_lot, plan["contract"] = l2, p2, alt["name"]
                    break
            plan["lots"], plan["risk_per_lot_inr"] = lots, round(per_lot, 0)
            plan["risk_inr"] = round(lots * per_lot, 0)
            blocked = None
            if lots < 1:
                blocked = f"1 lot risks INR {per_lot:,.0f} > {acc['risk_per_trade_pct']}% of capital: use a smaller contract or skip"
            elif len(held) >= acc["max_open_positions"]:
                blocked = f"position limit ({acc['max_open_positions']}) reached"
            elif open_risk + lots * per_lot > cap * acc["max_total_risk_pct"] / 100:
                blocked = f"total open risk would exceed {acc['max_total_risk_pct']}% of capital"
            if book == "real":
                dcs["blocked"] = blocked
            elif not blocked:
                positions["paper"].append({
                    "key": r["key"], "side": plan["side"], "entry": plan["entry"], "stop": plan["stop"],
                    "stop0": plan["stop"], "target": plan["target"], "lots": lots, "opened": today,
                    "extreme": plan["entry"], "t1_done": False, "last_bar": r["bar_date"],
                    "contract": plan["contract"], "lot_multiplier": round(per_lot / abs(plan["entry"] - plan["stop"]), 4)})
                held.add(r["key"])
                open_risk += lots * per_lot
                r.setdefault("paper_opened", True)

    # ---- final action per instrument (real book wins, else fresh decision)
    changes = []
    for r in results:
        real = r.get("manage", {}).get("real")
        if real:
            r["action"] = real["action"]
        else:
            a = r["decision"]["action"]
            r["action"] = a if not r["decision"].get("blocked") else f"{a} (blocked)"
        prev = last_sig.get(r["key"], {}).get("action")
        # HOLD with a moved stop is also worth a ping
        stop_moved = real and any("trail stop" in n for n in real.get("notes", []))
        if r["action"] != prev or stop_moved:
            changes.append(r)
        last_sig[r["key"]] = {"action": r["action"], "score": r["score"], "date": today}

    state.save_positions(positions)
    state.save_signals(last_sig)
    summary = {"generated": dt.datetime.now().isoformat(timespec="minutes"), "capital": cap,
               "macro": report.macro_snapshot(macro), "results": results, "errors": errors,
               "positions": positions, "changes": [c["key"] for c in changes],
               "paper_stats": report.journal_stats(state.read_journal())}
    report.write_all(summary)
    if send:
        alerts.dispatch(summary, changes, cfg)
    return summary
