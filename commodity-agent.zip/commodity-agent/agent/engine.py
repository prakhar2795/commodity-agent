"""Decision engine shared by live runs and the backtester."""
from __future__ import annotations

import datetime as dt
import logging
import os

import pandas as pd

from . import data, events, indicators as ind, signals as sig

log = logging.getLogger(__name__)


# ---------------------------------------------------------------- decisions
def open_decision(row: pd.Series, s: float, weekly_c: float, cfg: dict, event_today: bool) -> dict:
    """What to do when flat. Returns action + trade plan."""
    sc = cfg["signals"]
    close, a = float(row["close"]), float(row["atr"])
    side = "long" if s >= sc["buy_threshold"] else "short" if (s <= sc["sell_threshold"] and sc.get("allow_shorts", True)) else None
    notes = []
    if side is None:
        if abs(s) >= sc["watch_threshold"]:
            return {"action": "WATCH", "bias": "bullish" if s > 0 else "bearish",
                    "notes": [f"setup forming; needs score {'>= ' + str(sc['buy_threshold']) if s > 0 else '<= ' + str(sc['sell_threshold'])}"]}
        return {"action": "NO TRADE", "bias": "neutral", "notes": ["no edge: stay flat"]}

    sign = 1 if side == "long" else -1
    # filters that downgrade a signal to WATCH
    if sign * weekly_c < 0:
        notes.append("against the weekly trend")
    if side == "long" and row["rsi"] > 75 or side == "short" and row["rsi"] < 25:
        notes.append("RSI stretched: wait for a pullback")
    if abs(close - row["ema20"]) > 3 * a:
        notes.append("price > 3 ATR from EMA20: extended, wait for pullback")
    if event_today:
        notes.append("high-impact event within 24h: wait for it to pass")
    stop = close - sign * sc["stop_atr_mult"] * a
    target = close + sign * sc["target_r_multiple"] * abs(close - stop)
    plan = {"side": side, "entry": round(close, 2), "stop": round(stop, 2), "target": round(target, 2)}
    if notes:
        return {"action": "WATCH", "bias": "bullish" if sign > 0 else "bearish", "notes": notes, "plan": plan}
    return {"action": "BUY" if side == "long" else "SELL", "bias": "bullish" if sign > 0 else "bearish",
            "notes": [], "plan": plan}


def manage_position(pos: dict, row: pd.Series, s: float, cfg: dict) -> dict:
    """Update an open position with today's bar. Mutates pos; returns action dict."""
    sc = cfg["signals"]
    sign = 1 if pos["side"] == "long" else -1
    hi, lo, close, a = float(row["high"]), float(row["low"]), float(row["close"]), float(row["atr"])
    op = float(row["open"])

    # 1) stop hit? (gap through the stop fills at the open)
    if (sign > 0 and lo <= pos["stop"]) or (sign < 0 and hi >= pos["stop"]):
        fill = min(op, pos["stop"]) if sign > 0 else max(op, pos["stop"])
        return {"action": "EXIT", "reason": "stop-loss hit", "fill": round(fill, 2)}

    notes = []
    # 2) first target: book half, stop to breakeven
    if not pos.get("t1_done") and ((sign > 0 and hi >= pos["target"]) or (sign < 0 and lo <= pos["target"])):
        pos["t1_done"] = True
        pos["stop"] = max(pos["stop"], pos["entry"]) if sign > 0 else min(pos["stop"], pos["entry"])
        notes.append(f"T1 {pos['target']} reached: book 50%, stop moved to breakeven")
        partial = True
    else:
        partial = False

    # 3) chandelier trail from the best price since entry
    pos["extreme"] = max(pos.get("extreme", pos["entry"]), hi) if sign > 0 else min(pos.get("extreme", pos["entry"]), lo)
    trail = pos["extreme"] - sign * sc["trail_atr_mult"] * a
    new_stop = max(pos["stop"], trail) if sign > 0 else min(pos["stop"], trail)

    # 4) score flip -> exit on close
    if sign * s < sc["exit_flip"]:
        return {"action": "EXIT", "reason": f"trend flipped (score {s:+.0f})", "fill": round(close, 2),
                "partial": partial, "notes": notes}
    if sign * s < 20:
        tight = close - sign * 1.5 * a
        new_stop = max(new_stop, tight) if sign > 0 else min(new_stop, tight)
        notes.append("momentum fading: stop tightened to 1.5 ATR")
    if round(new_stop, 2) != round(pos["stop"], 2):
        notes.append(f"trail stop {pos['stop']:.2f} -> {new_stop:.2f}")
    pos["stop"] = round(new_stop, 2)
    return {"action": "BOOK PARTIAL" if partial else "HOLD", "reason": "trend intact", "notes": notes}


# ---------------------------------------------------------------- analysis
def session_date(now: dt.datetime | None = None) -> dt.date:
    """CME session date: the session for day D starts ~22:00 UTC on D-1."""
    now = now or dt.datetime.utcnow()
    return (now + dt.timedelta(hours=3)).date()


def analyse(key: str, inst: dict, cfg: dict, loader=None, macro: dict | None = None,
            now: dt.datetime | None = None) -> dict:
    """Full analysis for one instrument. Returns a dict ready for reporting."""
    macro = macro or {}
    g = data.fetch(inst["global_symbol"], loader=loader)
    fx = macro.get("usdinr")
    if fx is None:
        fx = pd.Series(1.0, index=g.index)
        log.warning("USDINR missing; INR conversion skipped")
    calib = (cfg.get("mcx_calibration") or {}).get(key)
    m = data.to_mcx(g, fx, inst, calib)

    sd = session_date(now)
    live = m.iloc[-1]
    done = m[m.index.date < sd] if (m.index.date >= sd).any() else m
    d = ind.add_all(done)
    w = data.weekly(done)
    comp = sig.components(d, w, macro.get("dxy"), fx, inst.get("uses_dxy", True))
    score, ranging = sig.score(comp, d["adx"], cfg["signals"]["min_adx_trend"])
    last, crow = d.iloc[-1], comp.iloc[-1]
    s = float(score.iloc[-1])

    today = dt.date.today()
    evs = events.upcoming(inst.get("events", []), cfg.get("calendar", {}), today, days=3)
    event_24h = any(e["in_days"] <= 1 for e in evs)

    res = {
        "key": key, "name": inst["name"], "unit": inst["mcx_unit"], "symbol": inst["global_symbol"],
        "bar_date": str(d.index[-1].date()), "close": round(float(last["close"]), 2),
        "live": round(float(live["close"]), 2), "global_close": round(float(g["close"].iloc[-1]), 2),
        "score": s, "score_prev": float(score.iloc[-2]), "score_5d": float(score.iloc[-6]),
        "conviction": sig.conviction(s), "regime": "ranging" if bool(ranging.iloc[-1]) else "trending",
        "explain": sig.explain(crow), "components": {k: round(float(v), 2) for k, v in crow.items()},
        "ind": {k: round(float(last[k]), 2) for k in
                ["ema20", "ema50", "ema200", "rsi", "macd_hist", "adx", "pdi", "mdi", "atr", "atr_pct",
                 "bb_pctb", "bb_width", "stoch_k", "st", "dc_hi", "dc_lo", "hi52", "lo52", "cci", "vol_ratio"]
                if pd.notna(last[k])},
        "squeeze": bool(last["squeeze"]),
        "levels": {**ind.swing_levels(d), "pivots": {k: round(v, 2) for k, v in ind.pivots_classic(d).items()}},
        "events": evs, "expiry": events.expiry_warning(key, cfg.get("calendar", {}), today),
        "_row": last, "_live_row": live, "_weekly_c": float(crow["weekly_trend"]),
    }
    res["decision"] = open_decision(last, s, res["_weekly_c"], cfg, event_24h)
    return res


def capital(cfg: dict) -> float:
    acc = cfg["account"]
    try:
        return float(os.environ.get(acc.get("capital_env", "TRADING_CAPITAL"), acc["default_capital"]))
    except ValueError:
        return float(acc["default_capital"])
