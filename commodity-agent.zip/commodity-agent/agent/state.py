"""Persistent state: open positions (real + paper), last signals, paper journal."""
from __future__ import annotations

import csv
import json
import os
from pathlib import Path

ROOT = Path(os.environ.get("AGENT_HOME", Path(__file__).resolve().parent.parent))
STATE = ROOT / "state"
POS_FILE = STATE / "positions.json"
SIG_FILE = STATE / "last_signals.json"
JOURNAL = STATE / "paper_journal.csv"
JOURNAL_COLS = ["opened", "closed", "key", "side", "entry", "exit", "stop0", "lots", "r_multiple", "pnl_inr", "reason"]


def _load(p: Path, default):
    try:
        return json.loads(p.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def _save(p: Path, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2, default=str))


def load_positions() -> dict:
    return _load(POS_FILE, {"real": [], "paper": []})


def save_positions(p: dict):
    _save(POS_FILE, p)


def load_signals() -> dict:
    return _load(SIG_FILE, {})


def save_signals(s: dict):
    _save(SIG_FILE, s)


def journal(row: dict):
    JOURNAL.parent.mkdir(parents=True, exist_ok=True)
    new = not JOURNAL.exists()
    with JOURNAL.open("a", newline="") as f:
        w = csv.DictWriter(f, fieldnames=JOURNAL_COLS)
        if new:
            w.writeheader()
        w.writerow({k: row.get(k, "") for k in JOURNAL_COLS})


def read_journal() -> list[dict]:
    if not JOURNAL.exists():
        return []
    with JOURNAL.open() as f:
        return list(csv.DictReader(f))
