"""Walk-forward backtest of the exact live rules (signal on close, enter next open)."""
from __future__ import annotations

import pandas as pd

from . import data, engine, indicators as ind, signals as sig
from .report import journal_stats


def backtest_frame(m: pd.DataFrame, cfg: dict, dxy=None, fx=None, uses_dxy=True,
                   cost_pct: float = 0.03, warmup: int = 260) -> dict:
    d = ind.add_all(m)
    w = data.weekly(m)
    comp = sig.components(d, w, dxy, fx, uses_dxy)
    score, _ = sig.score(comp, d["adx"], cfg["signals"]["min_adx_trend"])
    trades, pos, pending = [], None, None
    idx = d.index
    for i in range(warmup, len(d)):
        row, s = d.iloc[i], float(score.iloc[i])
        if pending is not None and pos is None:  # fill yesterday's signal at today's open
            side, a = pending
            sign = 1 if side == "long" else -1
            entry = float(row["open"])
            stop = entry - sign * cfg["signals"]["stop_atr_mult"] * a
            pos = {"side": side, "entry": entry, "stop": stop, "stop0": stop, "extreme": entry, "t1_done": False,
                   "target": entry + sign * cfg["signals"]["target_r_multiple"] * abs(entry - stop), "opened": idx[i]}
            pending = None
        if pos is not None:
            act = engine.manage_position(pos, row, s, cfg)
            if act["action"] == "EXIT":
                sign = 1 if pos["side"] == "long" else -1
                r0 = abs(pos["entry"] - pos["stop0"])
                fill = act["fill"]
                r = (0.5 * sign * (pos["target"] - pos["entry"]) + 0.5 * sign * (fill - pos["entry"])) / r0 if pos["t1_done"] \
                    else sign * (fill - pos["entry"]) / r0
                r -= cost_pct / 100 * pos["entry"] / r0
                trades.append({"opened": pos["opened"].date(), "closed": idx[i].date(), "side": pos["side"],
                               "entry": round(pos["entry"], 2), "exit": fill, "r_multiple": round(r, 2),
                               "bars": int((idx[:i + 1] >= pos["opened"]).sum()), "reason": act["reason"]})
                pos = None
            continue
        dec = engine.open_decision(row, s, float(comp["weekly_trend"].iloc[i]), cfg, event_today=False)
        if dec["action"] in ("BUY", "SELL"):
            pending = (dec["plan"]["side"], float(row["atr"]))
    stats = journal_stats(trades)
    tested = d.iloc[warmup:]
    stats["buy_hold_pct"] = round(float(tested["close"].iloc[-1] / tested["close"].iloc[0] - 1) * 100, 1) if len(tested) else None
    stats["avg_bars_held"] = round(sum(t["bars"] for t in trades) / len(trades), 1) if trades else 0
    stats["period"] = f"{tested.index[0].date()} to {tested.index[-1].date()}" if len(tested) else ""
    return {"stats": stats, "trades": trades}


def backtest_instrument(key: str, cfg: dict, loader=None, period: str = "10y") -> dict:
    inst = cfg["instruments"][key]
    g = data.fetch(inst["global_symbol"], period=period, loader=loader)
    fx = data.fetch(cfg["macro"]["usdinr"], period=period, loader=loader)["close"]
    try:
        dxy = data.fetch(cfg["macro"]["dxy"], period=period, loader=loader)["close"]
    except Exception:  # noqa: BLE001
        dxy = None
    m = data.to_mcx(g, fx, inst)
    return backtest_frame(m, cfg, dxy, fx, inst.get("uses_dxy", True))
