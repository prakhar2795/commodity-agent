"""Technical indicators implemented in plain pandas/numpy (no TA-Lib needed).

Every function takes an OHLCV DataFrame with columns
open, high, low, close, volume and returns Series/DataFrames aligned to it.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


# ---------- moving averages ----------
def sma(s: pd.Series, n: int) -> pd.Series:
    return s.rolling(n, min_periods=n).mean()


def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False, min_periods=n).mean()


def wilder(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()


# ---------- volatility ----------
def true_range(df: pd.DataFrame) -> pd.Series:
    pc = df["close"].shift(1)
    return pd.concat([df["high"] - df["low"], (df["high"] - pc).abs(), (df["low"] - pc).abs()], axis=1).max(axis=1)


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    return wilder(true_range(df), n)


def bollinger(s: pd.Series, n: int = 20, k: float = 2.0) -> pd.DataFrame:
    mid = sma(s, n)
    sd = s.rolling(n, min_periods=n).std(ddof=0)
    up, lo = mid + k * sd, mid - k * sd
    return pd.DataFrame({"bb_mid": mid, "bb_up": up, "bb_lo": lo,
                         "bb_pctb": (s - lo) / (up - lo), "bb_width": (up - lo) / mid})


def keltner(df: pd.DataFrame, n: int = 20, k: float = 1.5) -> pd.DataFrame:
    mid = ema(df["close"], n)
    a = atr(df, n)
    return pd.DataFrame({"kc_mid": mid, "kc_up": mid + k * a, "kc_lo": mid - k * a})


def squeeze_on(df: pd.DataFrame) -> pd.Series:
    """TTM-style squeeze: Bollinger Bands inside Keltner Channels = volatility coiling."""
    bb, kc = bollinger(df["close"]), keltner(df)
    return (bb["bb_up"] < kc["kc_up"]) & (bb["bb_lo"] > kc["kc_lo"])


# ---------- momentum ----------
def rsi(s: pd.Series, n: int = 14) -> pd.Series:
    d = s.diff()
    up, dn = wilder(d.clip(lower=0), n), wilder(-d.clip(upper=0), n)
    rs = up / dn.replace(0, np.nan)
    return (100 - 100 / (1 + rs)).fillna(100)


def macd(s: pd.Series, fast=12, slow=26, sig=9) -> pd.DataFrame:
    line = ema(s, fast) - ema(s, slow)
    signal = ema(line, sig)
    return pd.DataFrame({"macd": line, "macd_sig": signal, "macd_hist": line - signal})


def stochastic(df: pd.DataFrame, n=14, d=3) -> pd.DataFrame:
    ll, hh = df["low"].rolling(n).min(), df["high"].rolling(n).max()
    k = 100 * (df["close"] - ll) / (hh - ll).replace(0, np.nan)
    k = k.rolling(d).mean()  # slow %K
    return pd.DataFrame({"stoch_k": k, "stoch_d": k.rolling(d).mean()})


def roc(s: pd.Series, n: int = 10) -> pd.Series:
    return 100 * (s / s.shift(n) - 1)


def cci(df: pd.DataFrame, n: int = 20) -> pd.Series:
    tp = (df["high"] + df["low"] + df["close"]) / 3
    md = tp.rolling(n).apply(lambda x: np.abs(x - x.mean()).mean(), raw=True)
    return (tp - sma(tp, n)) / (0.015 * md)


# ---------- trend ----------
def adx(df: pd.DataFrame, n: int = 14) -> pd.DataFrame:
    up = df["high"].diff()
    dn = -df["low"].diff()
    plus_dm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=df.index)
    minus_dm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=df.index)
    a = atr(df, n)
    pdi = 100 * wilder(plus_dm, n) / a
    mdi = 100 * wilder(minus_dm, n) / a
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    return pd.DataFrame({"adx": wilder(dx, n), "pdi": pdi, "mdi": mdi})


def supertrend(df: pd.DataFrame, n: int = 10, mult: float = 3.0) -> pd.DataFrame:
    a = atr(df, n)
    hl2 = (df["high"] + df["low"]) / 2
    ub, lb = (hl2 + mult * a).to_numpy(), (hl2 - mult * a).to_numpy()
    close = df["close"].to_numpy()
    fub, flb = ub.copy(), lb.copy()
    direction = np.ones(len(df))
    st = np.full(len(df), np.nan)
    for i in range(1, len(df)):
        if np.isnan(ub[i]) or np.isnan(fub[i - 1]):
            continue
        fub[i] = ub[i] if (ub[i] < fub[i - 1] or close[i - 1] > fub[i - 1]) else fub[i - 1]
        flb[i] = lb[i] if (lb[i] > flb[i - 1] or close[i - 1] < flb[i - 1]) else flb[i - 1]
        if direction[i - 1] == 1:
            direction[i] = -1 if close[i] < flb[i] else 1
        else:
            direction[i] = 1 if close[i] > fub[i] else -1
        st[i] = flb[i] if direction[i] == 1 else fub[i]
    return pd.DataFrame({"st": st, "st_dir": direction}, index=df.index)


def ichimoku(df: pd.DataFrame) -> pd.DataFrame:
    h, l = df["high"], df["low"]
    tenkan = (h.rolling(9).max() + l.rolling(9).min()) / 2
    kijun = (h.rolling(26).max() + l.rolling(26).min()) / 2
    span_a = ((tenkan + kijun) / 2).shift(26)
    span_b = ((h.rolling(52).max() + l.rolling(52).min()) / 2).shift(26)
    return pd.DataFrame({"tenkan": tenkan, "kijun": kijun, "span_a": span_a, "span_b": span_b})


def donchian(df: pd.DataFrame, n: int = 20) -> pd.DataFrame:
    # previous n bars (exclude today) so a breakout is measurable
    return pd.DataFrame({"dc_hi": df["high"].rolling(n).max().shift(1),
                         "dc_lo": df["low"].rolling(n).min().shift(1)})


# ---------- volume ----------
def obv(df: pd.DataFrame) -> pd.Series:
    sign = np.sign(df["close"].diff()).fillna(0)
    return (sign * df["volume"].fillna(0)).cumsum()


def slope(s: pd.Series, n: int = 10) -> pd.Series:
    """Normalised linear-regression slope over n bars (% of mean per bar)."""
    x = np.arange(n)
    x = x - x.mean()

    def _f(y):
        m = y.mean()
        return 0.0 if m == 0 else (np.dot(x, y - m) / np.dot(x, x)) / abs(m) * 100
    return s.rolling(n).apply(_f, raw=True)


# ---------- structure ----------
def pivots_classic(df: pd.DataFrame) -> dict:
    """Classic floor pivots from the last completed bar."""
    h, l, c = df["high"].iloc[-1], df["low"].iloc[-1], df["close"].iloc[-1]
    p = (h + l + c) / 3
    lv = {"P": p, "R1": 2 * p - l, "S1": 2 * p - h, "R2": p + (h - l), "S2": p - (h - l)}
    return {k: round(float(v), 2) for k, v in lv.items()}


def swing_levels(df: pd.DataFrame, lookback: int = 120, w: int = 5, k: int = 3) -> dict:
    """Nearest support/resistance from fractal swing highs/lows, clustered."""
    d = df.tail(lookback)
    hi, lo, c = d["high"], d["low"], d["close"].iloc[-1]
    sh = hi[(hi == hi.rolling(2 * w + 1, center=True).max())].dropna()
    sl = lo[(lo == lo.rolling(2 * w + 1, center=True).min())].dropna()
    res = sorted([v for v in sh.values if v > c])[:k]
    sup = sorted([v for v in sl.values if v < c], reverse=True)[:k]
    return {"resistance": [round(float(v), 2) for v in res], "support": [round(float(v), 2) for v in sup]}


# ---------- one call ----------
def add_all(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    c = out["close"]
    for n in (20, 50, 200):
        out[f"ema{n}"] = ema(c, n)
    out["atr"] = atr(out)
    out["atr_pct"] = out["atr"] / c * 100
    out["rsi"] = rsi(c)
    out = out.join(macd(c)).join(bollinger(c)).join(stochastic(out)).join(adx(out))
    out = out.join(supertrend(out)).join(ichimoku(out)).join(donchian(out))
    out["roc10"] = roc(c, 10)
    out["cci"] = cci(out)
    out["squeeze"] = squeeze_on(out)
    out["obv"] = obv(out)
    # net share of the last 10 bars' volume that went up (-1..+1)
    out["obv_slope"] = out["obv"].diff(10) / (sma(out["volume"], 20) * 10).replace(0, np.nan)
    out["vol_ratio"] = out["volume"] / sma(out["volume"], 20)
    out["ema50_slope"] = slope(out["ema50"], 10)
    out["hi52"] = out["high"].rolling(252, min_periods=60).max()
    out["lo52"] = out["low"].rolling(252, min_periods=60).min()
    return out
