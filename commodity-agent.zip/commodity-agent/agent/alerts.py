"""Alert channels: Telegram bot + Gmail SMTP. Credentials come from environment variables.

TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
GMAIL_USER, GMAIL_APP_PASSWORD, ALERT_EMAIL_TO
"""
from __future__ import annotations

import logging
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import requests

from . import report

log = logging.getLogger(__name__)


def telegram(text: str) -> bool:
    tok, chat = os.environ.get("TELEGRAM_BOT_TOKEN"), os.environ.get("TELEGRAM_CHAT_ID")
    if not tok or not chat:
        log.info("Telegram not configured; skipping")
        return False
    r = requests.post(f"https://api.telegram.org/bot{tok}/sendMessage",
                      json={"chat_id": chat, "text": text, "disable_web_page_preview": True}, timeout=20)
    if not r.ok:
        log.error("Telegram error %s: %s", r.status_code, r.text[:200])
    return r.ok


def email(subject: str, html_body: str, to: str | None = None) -> bool:
    user, pw = os.environ.get("GMAIL_USER"), os.environ.get("GMAIL_APP_PASSWORD")
    to = to or os.environ.get("ALERT_EMAIL_TO") or user
    if not user or not pw:
        log.info("Email not configured; skipping")
        return False
    msg = MIMEMultipart("alternative")
    msg["Subject"], msg["From"], msg["To"] = subject, user, to
    msg.attach(MIMEText(html_body, "html"))
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=30) as s:
        s.login(user, pw)
        s.sendmail(user, [to], msg.as_string())
    return True


def dispatch(summary: dict, changes: list[dict], cfg: dict):
    a = cfg.get("alerts", {})
    digest = os.environ.get("AGENT_DIGEST", "0") == "1" and a.get("daily_digest", True)
    if not changes and not digest and a.get("only_on_change", True):
        log.info("No signal changes; no alert sent")
        return
    urgent = [c for c in changes if c["action"].split(" (")[0] in ("BUY", "SELL", "EXIT", "BOOK PARTIAL")]
    if a.get("telegram", True):
        telegram(report.telegram_text(summary, changes if (changes and not digest) else []))
    if a.get("email", True) and (digest or urgent):
        tag = ", ".join(f"{c['name']} {c['action']}" for c in urgent) or "daily brief"
        email(f"[Commodity agent] {tag}", report.email_html(summary, changes))
