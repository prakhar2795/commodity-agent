"""Signal engine: turns indicators into a -100..+100 score, then into an action.

Score = sum(weight x component), each component in [-1, +1].
Weights sum to 100, so the score reads like a conviction percentage.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from . import indicators as ind

WEIGHTS = {
    # trend (45)
    "weekly_trend": 12, "ema_stack": 10, "supertrend": 8, "ichimoku": 7, "adx_direction": 8,
    # momentum (25)
    "rsi": 8, "macd": 9, "stochastic": 4, "roc": 4,
    # breakout / volatility (15)
    "donchian": 8, "squeeze_release": 4, "bollinger": 3,
    # volume (5)
    "obv": 5,
    # intermarket (10)
    "dxy": 5, "usdinr": 5,
}
TREND_KEYS = {"weekly_trend", "ema_stack", "supertrend", "ichimoku", "adx_direction", "donchian", "squeeze_release"}

LABELS = {
    "weekly_trend": ("weekly trend up", "weekly trend down"),
    "ema_stack": ("price above rising EMA 20/50/200 stack", "price below falling EMA stack"),
    "supertrend": ("Supertrend bullish", "Supertrend bearish"),
    "ichimoku": ("above Ichimoku cloud", "below Ichimoku cloud"),
    "adx_direction": ("ADX confirms buyers in control", "ADX confirms sellers in control"),
    "rsi": ("RSI momentum positive", "RSI momentum negative"),
    "macd": ("MACD histogram rising", "MACD histogram falling"),
    "stochastic": ("Stochastic turning up", "Stochastic turning down"),
    "roc": ("10-day rate of change positive", "10-day rate of change negative"),
    "donchian": ("20-day breakout / upper channel", "20-day breakdown / lower channel"),
    "squeeze_release": ("volatility squeeze released upward", "volatility squeeze released downward"),
    "bollinger": ("riding upper Bollinger band", "riding lower Bollinger band"),
    "obv": ("volume flowing in (OBV up)", "volume flowing out (OBV down)"),
    "dxy": ("US dollar weakening (tailwind)", "US dollar strengthening (headwind)"),
    "usdinr": ("rupee weakening lifts MCX price", "rupee strengthening drags MCX price"),
}


def _clip(x):
    return np.clip(x, -1.0, 1.0)


def components(d: pd.DataFrame, w: pd.DataFrame, dxy: pd.Series | None, fx: pd.Series | None,
               uses_dxy: bool = True) -> pd.DataFrame:
    """Vectorised component values for every bar. d = daily with indicators, w = weekly OHLCV."""
    c = d["close"]
    comp = pd.DataFrame(index=d.index)

    # --- weekly trend (no look-ahead: weekly values ffilled onto daily bars)
    wc = w["close"]
    we20, we50 = ind.ema(wc, 20), ind.ema(wc, 50)
    wscore = (np.sign(wc - we20) * 0.5 + np.sign(we20 - we50) * 0.5).fillna(np.sign(wc - we20) * 0.5)
    comp["weekly_trend"] = wscore.reindex(d.index, method="ffill").fillna(0)

    comp["ema_stack"] = ((np.sign(c - d["ema20"]) + np.sign(d["ema20"] - d["ema50"]) +
                          np.sign(d["ema50"] - d["ema200"]).fillna(0)) / 3).fillna(0)
    comp["supertrend"] = d["st_dir"].where(d["st"].notna(), 0)

    top = d[["span_a", "span_b"]].max(axis=1)
    bot = d[["span_a", "span_b"]].min(axis=1)
    cloud = np.where(c > top, 1.0, np.where(c < bot, -1.0, 0.0))
    comp["ichimoku"] = _clip(cloud * 0.7 + np.sign(d["tenkan"] - d["kijun"]).fillna(0) * 0.3)

    comp["adx_direction"] = (np.sign(d["pdi"] - d["mdi"]) * np.minimum(d["adx"] / 40, 1)).fillna(0)

    r = d["rsi"]
    rv = _clip((r - 50) / 20)
    rv = np.where(r > 75, 0.3, np.where(r < 25, -0.3, rv))  # stretched: momentum yes, chase no
    comp["rsi"] = rv

    h = d["macd_hist"]
    comp["macd"] = (np.sign(h) * 0.6 + np.sign(h - h.shift(3)) * 0.4).fillna(0)

    k, dd = d["stoch_k"], d["stoch_d"]
    comp["stochastic"] = np.where((k > dd) & (k < 80), 1.0, np.where((k < dd) & (k > 20), -1.0, 0.0))

    comp["roc"] = _clip(d["roc10"] / (d["atr_pct"] * 3)).fillna(0)

    hi, lo = d["dc_hi"], d["dc_lo"]
    inside = _clip((2 * (c - lo) / (hi - lo) - 1) * 0.4)
    comp["donchian"] = np.where(c > hi, 1.0, np.where(c < lo, -1.0, inside))
    comp["donchian"] = comp["donchian"].fillna(0)

    was_sq = d["squeeze"].rolling(5).max().shift(1).fillna(0).astype(bool)
    released = was_sq & ~d["squeeze"]
    comp["squeeze_release"] = np.where(released, np.sign(h), 0.0)

    comp["bollinger"] = _clip((d["bb_pctb"] - 0.5) * 2 * 0.5).fillna(0)
    comp["obv"] = _clip(d["obv_slope"] * 3).fillna(0)

    if dxy is not None and uses_dxy:
        x = dxy.reindex(d.index).ffill()
        comp["dxy"] = _clip(-(x / ind.ema(x, 20) - 1) / 0.01).fillna(0)
    else:
        comp["dxy"] = 0.0
    if fx is not None:
        f = fx.reindex(d.index).ffill()
        comp["usdinr"] = _clip((f / ind.ema(f, 20) - 1) / 0.005).fillna(0)
    else:
        comp["usdinr"] = 0.0
    return comp.astype(float)


def score(comp: pd.DataFrame, adx: pd.Series, min_adx: float) -> tuple[pd.Series, pd.Series]:
    ranging = adx < min_adx
    total = pd.Series(0.0, index=comp.index)
    for k, wt in WEIGHTS.items():
        v = comp[k] * wt
        if k in TREND_KEYS:
            v = v.where(~ranging, v * 0.6)  # trend signals are less reliable in a range
        total += v
    return total.round(1), ranging


def explain(row: pd.Series, n: int = 4) -> dict:
    contrib = {k: float(row[k]) * WEIGHTS[k] for k in WEIGHTS}
    bull = sorted([(v, k) for k, v in contrib.items() if v > 0.5], reverse=True)[:n]
    bear = sorted([(v, k) for k, v in contrib.items() if v < -0.5])[:n]
    return {"bullish": [f"{LABELS[k][0]} (+{v:.0f})" for v, k in bull],
            "bearish": [f"{LABELS[k][1]} ({v:.0f})" for v, k in bear]}


def conviction(s: float) -> str:
    a = abs(s)
    return "strong" if a >= 75 else "moderate" if a >= 55 else "weak" if a >= 35 else "none"


def lots_for(capital: float, risk_pct: float, entry: float, stop: float, lot_mult: float) -> tuple[int, float]:
    per_lot = abs(entry - stop) * lot_mult
    if per_lot <= 0:
        return 0, 0.0
    return int(math.floor(capital * risk_pct / 100 / per_lot)), per_lot
