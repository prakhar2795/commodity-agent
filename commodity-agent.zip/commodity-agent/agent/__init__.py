"""Commodity swing-trading decision-support agent (MCX + COMEX/NYMEX)."""
