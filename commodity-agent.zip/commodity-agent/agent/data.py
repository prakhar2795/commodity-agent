"""Market data: global futures from Yahoo Finance, converted to MCX-implied INR prices."""
from __future__ import annotations

import logging

import numpy as np
import pandas as pd

log = logging.getLogger(__name__)


def _yf_download(symbol: str, period: str = "3y", interval: str = "1d") -> pd.DataFrame:
    import yfinance as yf  # imported lazily so tests run without network
    df = yf.download(symbol, period=period, interval=interval, progress=False, auto_adjust=False)
    if df is None or df.empty:
        raise RuntimeError(f"No data for {symbol}")
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    df = df.rename(columns=str.lower)[["open", "high", "low", "close", "volume"]]
    df.index = pd.to_datetime(df.index).tz_localize(None)
    return df.dropna(subset=["close"])


def fetch(symbol: str, period: str = "3y", interval: str = "1d", loader=None) -> pd.DataFrame:
    return (loader or _yf_download)(symbol, period, interval)


def to_mcx(global_df: pd.DataFrame, usdinr: pd.Series, inst: dict, calib_ltp: float | None = None) -> pd.DataFrame:
    """Convert a USD futures OHLCV frame into an MCX-implied INR frame."""
    fx = usdinr.reindex(global_df.index).ffill().bfill()
    k = inst.get("unit_factor", 1.0) * (1 + inst.get("duty", 0.0))
    out = global_df.copy()
    for col in ("open", "high", "low", "close"):
        out[col] = global_df[col] * fx * k
    if calib_ltp:
        ratio = calib_ltp / out["close"].iloc[-1]
        if 0.8 < ratio < 1.2:  # guard against a typo
            for col in ("open", "high", "low", "close"):
                out[col] *= ratio
        else:
            log.warning("Calibration ratio %.3f out of range; ignored", ratio)
    return out


def weekly(df: pd.DataFrame) -> pd.DataFrame:
    return df.resample("W-FRI").agg({"open": "first", "high": "max", "low": "min",
                                     "close": "last", "volume": "sum"}).dropna(subset=["close"])


def synthetic(n: int = 800, seed: int = 7, start: float = 2000.0, drift: float = 0.0003,
              vol: float = 0.012, regime_len: int = 120) -> pd.DataFrame:
    """Trending/ranging random walk for offline tests and backtest sanity checks."""
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=n)
    regimes = np.repeat(rng.choice([-1.5, 0, 1.5], size=n // regime_len + 1), regime_len)[:n]
    rets = rng.normal(drift + regimes * vol * 0.12, vol, n)
    close = start * np.exp(np.cumsum(rets))
    op = np.r_[close[0], close[:-1]] * (1 + rng.normal(0, vol / 4, n))
    hi = np.maximum(op, close) * (1 + np.abs(rng.normal(0, vol / 2, n)))
    lo = np.minimum(op, close) * (1 - np.abs(rng.normal(0, vol / 2, n)))
    volu = rng.integers(50_000, 150_000, n).astype(float)
    return pd.DataFrame({"open": op, "high": hi, "low": lo, "close": close, "volume": volu}, index=idx)
