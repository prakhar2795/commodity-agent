"""Offline tests: synthetic market data, no network needed.  Run: python -m pytest -q"""
import os
import tempfile

import numpy as np
import pandas as pd

os.environ["AGENT_HOME"] = tempfile.mkdtemp()

from agent import data, engine, indicators as ind, runner, backtest, state  # noqa: E402

SYMS = {"GC=F": (2400, 11), "SI=F": (30, 12), "CL=F": (75, 13), "NG=F": (3, 14), "HG=F": (4.3, 15),
        "INR=X": (84, 16), "DX-Y.NYB": (102, 17), "^TNX": (4.2, 18)}


def fake_loader(symbol, period="3y", interval="1d"):
    start, seed = SYMS[symbol]
    vol = 0.002 if symbol in ("INR=X", "DX-Y.NYB") else 0.013
    return data.synthetic(n=900, seed=seed, start=start, vol=vol)


def cfg():
    import yaml
    from pathlib import Path
    return yaml.safe_load((Path(__file__).resolve().parent.parent / "config.yaml").read_text())


def test_indicators_sane():
    df = ind.add_all(data.synthetic())
    last = df.iloc[-1]
    assert 0 <= last["rsi"] <= 100
    assert 0 <= last["adx"] <= 100
    assert last["atr"] > 0
    assert last["bb_up"] > last["bb_mid"] > last["bb_lo"]
    assert set(df["st_dir"].dropna().unique()) <= {1.0, -1.0}


def test_rsi_extremes():
    up = pd.DataFrame({"close": np.linspace(100, 200, 60)})
    assert ind.rsi(up["close"]).iloc[-1] > 95


def test_mcx_conversion_gold():
    g = pd.DataFrame({"open": [2400.0], "high": [2400.0], "low": [2400.0], "close": [2400.0], "volume": [1]},
                     index=pd.to_datetime(["2026-09-25"]))
    fx = pd.Series([84.0], index=g.index)
    inst = {"unit_factor": 10 / 31.1035, "duty": 0.06}
    v = data.to_mcx(g, fx, inst)["close"].iloc[0]
    assert abs(v - 2400 * 84 * 10 / 31.1035 * 1.06) < 1


def test_position_sizing():
    from agent.signals import lots_for
    lots, per = lots_for(300000, 0.5, 118000, 116500, 10)  # risk 1500*10 = 15000/lot vs 1500 budget
    assert lots == 0 and per == 15000
    lots, per = lots_for(300000, 1.0, 5500, 5400, 10)       # 1000/lot vs 3000 budget
    assert lots == 3


def test_manage_stop_and_target():
    c = cfg()
    pos = {"side": "long", "entry": 100.0, "stop": 96.0, "target": 108.0, "extreme": 100.0, "t1_done": False}
    row = pd.Series({"open": 101, "high": 109, "low": 100.5, "close": 107, "atr": 2.0})
    act = engine.manage_position(pos, row, 60, c)
    assert act["action"] == "BOOK PARTIAL" and pos["stop"] >= 100
    row2 = pd.Series({"open": 99, "high": 99.5, "low": 95, "close": 96, "atr": 2.0})
    assert engine.manage_position(pos, row2, 60, c)["action"] == "EXIT"


def test_full_run_offline():
    c = cfg()
    s = runner.run(c, loader=fake_loader, send=False)
    assert not s["errors"], s["errors"]
    assert len(s["results"]) == 4  # natgas disabled
    for r in s["results"]:
        assert -100 <= r["score"] <= 100
        assert r["action"]
    assert (state.ROOT / "reports" / "latest.json").exists()
    # second run is idempotent on the same bar
    s2 = runner.run(c, loader=fake_loader, send=False)
    assert [r["score"] for r in s2["results"]] == [r["score"] for r in s["results"]]


def test_backtest_runs():
    c = cfg()
    m = data.synthetic(n=1500, seed=3)
    res = backtest.backtest_frame(m, c)
    assert res["stats"]["trades"] > 5


def test_paper_open_and_smaller_contract_fallback():
    c = cfg()
    c["signals"]["buy_threshold"], c["signals"]["sell_threshold"] = 10, -10
    c["signals"]["watch_threshold"] = 5
    state.save_positions({"real": [], "paper": []})
    s = runner.run(c, loader=fake_loader, send=False)
    paper = s["positions"]["paper"]
    assert paper, "expected at least one paper position"
    assert len(paper) <= c["account"]["max_open_positions"]
    for p in paper:
        assert p["lots"] >= 1 and "contract" in p
