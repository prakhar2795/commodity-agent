# Commodity Agent — MCX + COMEX/NYMEX swing-trading assistant

Decision support, **not** an auto-trader and **not financial advice**. It scores gold, silver, crude, copper (and natural gas when enabled) every weekday, manages stops on your open positions, keeps its own paper-trading ledger, and messages you on Telegram + email when something changes.

## How it works

```
Yahoo Finance (GC=F, SI=F, CL=F, HG=F, NG=F, INR=X, DXY, US10Y)
   -> MCX-implied INR prices   (global x USDINR x unit factor x (1+duty) [x calibration])
   -> 25+ indicators           (EMA 20/50/200, RSI, MACD, ADX/DMI, ATR, Bollinger, Keltner squeeze,
                                Supertrend, Ichimoku, Donchian, Stochastic, ROC, CCI, OBV, pivots, swing S/R)
   -> 15 weighted components   -> score -100..+100 (trend 45, momentum 25, breakout 15, volume 5, intermarket 10)
   -> filters                  (weekly trend, RSI stretch, >3 ATR extension, event risk, position/risk limits)
   -> action                   BUY / SELL / HOLD / BOOK PARTIAL / EXIT / WATCH / NO TRADE
   -> plan                     entry, 2-ATR stop, 2R target, lots sized to your risk %, smaller-contract fallback
   -> reports/latest.{json,md} + Telegram + Gmail
```

Signals use **completed daily bars only** (confirm on close). The still-forming bar is used only to catch a stop hit intraday.

## Setup (about 15 minutes)

1. **Create a GitHub repo** (e.g. `commodity-agent`) and push this folder:
   ```bash
   git init && git add . && git commit -m "commodity agent"
   git branch -M main
   git remote add origin https://github.com/<you>/commodity-agent.git
   git push -u origin main
   ```
   Public repo = free unlimited Actions minutes and lets the daily Claude brief read `reports/latest.json`. Capital and tokens stay in Secrets, never in files. Your positions file is visible if public; make it private if you prefer (then the Claude brief falls back to its own analysis).
2. **Telegram bot:** message `@BotFather` -> `/newbot` -> copy the token. Send any message to your bot, then open `https://api.telegram.org/bot<TOKEN>/getUpdates` and copy `chat.id`.
3. **Gmail app password:** Google Account -> Security -> 2-Step Verification on -> App passwords -> create one for "Mail".
4. **Repo -> Settings -> Secrets and variables -> Actions**, add:
   `TRADING_CAPITAL` (e.g. 300000), `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, `GMAIL_USER`, `GMAIL_APP_PASSWORD`, `ALERT_EMAIL_TO`.
5. **Actions tab -> commodity-agent -> Run workflow** with mode `backtest` first, then `digest`. Check Telegram and email.

It then runs Mon–Fri at 08:10, 18:40 and 22:40 IST.

## Daily use

| You want to | Do this |
|---|---|
| Record a real trade you placed | `python -m agent open gold_mini long 118450 --stop 116900 --target 121550 --lots 1`, commit + push (or edit `state/positions.json` on GitHub) |
| Record that you exited | `python -m agent close gold_mini` |
| See positions + paper scorecard | `python -m agent status` |
| Test the rules on 10 years | `python -m agent backtest` |
| Run locally without sending | `python -m agent run --no-send` |
| Calibrate to the real MCX price | put today's MCX LTP under `mcx_calibration:` in `config.yaml` |
| Get contract-roll reminders | add expiry dates under `calendar.expiries` |

## Tuning (config.yaml)

- `risk_per_trade_pct`: 0.5 in the first live months, max 1.0 later.
- `buy_threshold` / `sell_threshold`: +/-55 by default. Raise to 65 for fewer, stronger signals.
- `stop_atr_mult` 2.0, `trail_atr_mult` 3.0, `target_r_multiple` 2.0.
- `natgas_mini.enabled`: false until you pass the go-live gate.
- Update `calendar.fomc` every January and add CPI dates if you want them flagged.

Change one parameter at a time and re-run the backtest before trusting it.

## Honest limits

- MCX prices are **implied** from global futures; the real MCX quote can differ by the local premium and at the 9:00 AM open. Always confirm on your broker's screen.
- Yahoo data is free and delayed/unofficial. For production, swap `data._yf_download` for your broker's API (Zerodha Kite, Upstox, Angel SmartAPI).
- Backtests on past data overstate future results. The paper ledger is the real test.

## Tests

`python -m pytest -q` runs fully offline on synthetic data.
